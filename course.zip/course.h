/**
 * @file course.h
 * @author Zhifu Sun
 * @brief include typedef struct and functions for course
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief struct of course
 * 
 */
typedef struct _course 
{
  char name[100]; /**<course name*/
  char code[10];  /**<course code*/
  Student *students; /**< pointer of a student */
  int total_students; /**< the number of students*/
} Course;
/**
 * @brief 
 * 
 * @param course 
 * @param student
 * @return nothing 
 */
void enroll_student(Course *course, Student *student);
/**
 * @brief 
 * 
 * @param course
 * @return nothing 
 */
void print_course(Course *course);
/**
 * @brief 
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);
/**
 * @brief 
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


